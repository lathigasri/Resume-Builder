
package resume;

public class Resume {

    public static void main(String[] args) {
        // TODO code application logic here
       login loginFrame= new login();
       loginFrame.setVisible(true);
       loginFrame.pack();
       loginFrame.setLocationRelativeTo(null);
 
    }
    
}
