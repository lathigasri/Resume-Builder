
package resume;

class JOptioPane {

    static int ERROR_MESSAGE;
    
}
